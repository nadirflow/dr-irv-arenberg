<?php

define('WCFMapi_TOKEN', 'wcfmapi');

define('WCFMapi_TEXT_DOMAIN', 'wcfm-marketplace-rest-api');

define('WCFMapi_VERSION', '1.4.4');

define('WCFMapi_SERVER_URL', 'https://wclovers.com');

?>